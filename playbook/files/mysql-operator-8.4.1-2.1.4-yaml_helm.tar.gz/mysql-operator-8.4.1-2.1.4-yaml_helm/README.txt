Copyright (c) 2020, 2024, Oracle and/or its affiliates.

This is a release of MySQL Operator, a Kubernetes Operator for MySQL InnoDB Cluster

License information can be found in the LICENSE file.
This distribution may include materials developed by third parties. For license
and attribution notices for these materials, please refer to the LICENSE file.

For more information on MySQL Operator visit https://dev.mysql.com/doc/mysql-operator/en/
For additional downloads and the source of MySQL Operator visit http://dev.mysql.com/downloads
and https://github.com/mysql

MySQL Operator is brought to you by the MySQL team at Oracle.

